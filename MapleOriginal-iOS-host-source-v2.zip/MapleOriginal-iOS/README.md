# Original-resource iOS host

This contains the iOS host only. It has no substitute game scene and bundles no proprietary artwork in source control.

The build must place a successfully generated, validated OpenMS offline web release at `WebContent/` before XcodeGen runs. The host serves these bundled files over loopback and presents the actual upstream client in WKWebView. It adds touch keys while preserving original 1024×768 game coordinates. Source: `tensorfish/openms` commit `3e379cfb05beb29ae8413352c8a3345783eb35da`, GPL-3.0-or-later. Include the upstream license and source identity with packaged releases. The game artwork/data retains its respective ownership.

This is a porting host, not proof that a particular game asset set renders or plays correctly. Compilation, local HTTP serving, WebGL rendering, multiple simultaneous touch keys, save persistence and audio need independent validation. No public web asset bundle is published by this host.
