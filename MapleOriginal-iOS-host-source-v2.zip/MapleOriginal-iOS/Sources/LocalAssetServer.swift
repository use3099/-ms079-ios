import Foundation
import Network

/// Serves bundled game files on loopback. No remote host or game account is involved.
final class LocalAssetServer {
    private let queue = DispatchQueue(label: "maple.local-assets")
    private var listener: NWListener?
    private var connections: [ObjectIdentifier: NWConnection] = [:]
    private let root: URL
    private let port: UInt16 = 8739

    init(root: URL) { self.root = root.resolvingSymlinksInPath().standardizedFileURL }

    func start(completion: @escaping (Result<URL, Error>) -> Void) throws {
        let parameters = NWParameters.tcp
        parameters.requiredLocalEndpoint = .hostPort(host: "127.0.0.1", port: NWEndpoint.Port(rawValue: port)!)
        let server = try NWListener(using: parameters)
        var completed = false
        server.stateUpdateHandler = { [weak self] state in
            guard let self = self, !completed else { return }
            switch state {
            case .ready:
                completed = true
                let url = URL(string: "http://127.0.0.1:\(self.port)/")!
                DispatchQueue.main.async { completion(.success(url)) }
            case .failed(let error):
                completed = true
                DispatchQueue.main.async { completion(.failure(error)) }
            default: break
            }
        }
        server.newConnectionHandler = { [weak self] connection in
            guard let self = self else { connection.cancel(); return }
            let id = ObjectIdentifier(connection)
            self.connections[id] = connection
            connection.stateUpdateHandler = { [weak self] state in
                switch state {
                case .cancelled, .failed: self?.connections.removeValue(forKey: id)
                default: break
                }
            }
            connection.start(queue: self.queue)
            self.receive(connection, buffer: Data(), remaining: 16)
        }
        listener = server
        server.start(queue: queue)
    }

    private func receive(_ connection: NWConnection, buffer: Data, remaining: Int) {
        guard remaining > 0, buffer.count < 16384 else { connection.cancel(); return }
        connection.receive(minimumIncompleteLength: 1, maximumLength: 16384 - buffer.count) { [weak self] data, _, complete, error in
            guard let self = self else { connection.cancel(); return }
            var next = buffer
            if let data = data { next.append(data) }
            if let marker = next.range(of: Data("\r\n\r\n".utf8)) {
                self.respond(connection, request: String(decoding: next[..<marker.lowerBound], as: UTF8.self))
            } else if error != nil || complete {
                connection.cancel()
            } else {
                self.receive(connection, buffer: next, remaining: remaining - 1)
            }
        }
    }

    private func respond(_ connection: NWConnection, request: String) {
        let lines = request.components(separatedBy: "\r\n")
        let first = (lines.first ?? "").split(separator: " ")
        guard first.count == 3, first[0] == "GET" || first[0] == "HEAD" else {
            send(connection, status: "405 Method Not Allowed", body: Data()); return
        }
        let path = URLComponents(string: String(first[1]))?.path ?? ""
        guard path.hasPrefix("/"), !path.contains("\0"), !path.contains("\\"),
              !path.split(separator: "/").contains("..") else {
            send(connection, status: "400 Bad Request", body: Data()); return
        }
        let relative = path == "/" ? "index.html" : String(path.dropFirst())
        let file = root.appendingPathComponent(relative).resolvingSymlinksInPath().standardizedFileURL
        guard file.path.hasPrefix(root.path + "/"),
              let data = try? Data(contentsOf: file, options: .mappedIfSafe) else {
            send(connection, status: "404 Not Found", body: Data()); return
        }
        let mime = mimeType(file.pathExtension.lowercased())
        let head = first[0] == "HEAD"
        let range = lines.first { $0.lowercased().hasPrefix("range:") }
        if let range = range, let bounds = byteRange(range, count: data.count) {
            let body = data.subdata(in: bounds)
            send(connection, status: "206 Partial Content", body: head ? Data() : body,
                 headers: ["Content-Type": mime, "Content-Range": "bytes \(bounds.lowerBound)-\(bounds.upperBound - 1)/\(data.count)"],
                 length: bounds.count)
        } else if range != nil {
            send(connection, status: "416 Range Not Satisfiable", body: Data(),
                 headers: ["Content-Range": "bytes */\(data.count)"])
        } else {
            send(connection, status: "200 OK", body: head ? Data() : data,
                 headers: ["Content-Type": mime], length: data.count)
        }
    }

    private func byteRange(_ header: String, count: Int) -> Range<Int>? {
        guard count > 0, let marker = header.range(of: "bytes=") else { return nil }
        let parts = header[marker.upperBound...].split(separator: "-", omittingEmptySubsequences: false)
        guard parts.count == 2 else { return nil }
        if parts[0].isEmpty {
            guard let length = Int(parts[1]), length > 0 else { return nil }
            return max(0, count - min(length, count))..<count
        }
        guard let lower = Int(parts[0]), lower >= 0, lower < count else { return nil }
        let last = parts[1].isEmpty ? count - 1 : (Int(parts[1]) ?? -1)
        guard last >= lower else { return nil }
        return lower..<(min(last, count - 1) + 1)
    }

    private func send(_ connection: NWConnection, status: String, body: Data,
                      headers: [String: String] = [:], length: Int? = nil) {
        var response = "HTTP/1.1 \(status)\r\nConnection: close\r\nAccept-Ranges: bytes\r\nCache-Control: no-cache\r\nContent-Length: \(length ?? body.count)\r\n"
        for (key, value) in headers { response += "\(key): \(value)\r\n" }
        response += "\r\n"
        connection.send(content: Data(response.utf8), completion: .contentProcessed { error in
            if error != nil || body.isEmpty { connection.cancel(); return }
            connection.send(content: body, completion: .contentProcessed { _ in connection.cancel() })
        })
    }

    private func mimeType(_ ext: String) -> String {
        switch ext {
        case "html": return "text/html; charset=utf-8"
        case "js", "mjs": return "text/javascript; charset=utf-8"
        case "json", "webmanifest": return "application/json"
        case "css": return "text/css; charset=utf-8"
        case "png": return "image/png"
        case "svg": return "image/svg+xml"
        case "mp3": return "audio/mpeg"
        case "wav": return "audio/wav"
        case "wasm": return "application/wasm"
        case "woff2": return "font/woff2"
        default: return "application/octet-stream"
        }
    }
}
