import UIKit
import WebKit

private final class GameKeyButton: UIButton {
    let code: String
    init(_ title: String, code: String) {
        self.code = code
        super.init(frame: .zero)
        setTitle(title, for: .normal)
        titleLabel?.font = .systemFont(ofSize: 15, weight: .semibold)
        backgroundColor = UIColor(white: 0.12, alpha: 0.7)
        layer.cornerRadius = 20
        layer.borderWidth = 1
        layer.borderColor = UIColor(white: 1, alpha: 0.4).cgColor
        isExclusiveTouch = false
    }
    required init?(coder: NSCoder) { fatalError("Use programmatic initialization") }
}

final class OriginalGameController: UIViewController, WKNavigationDelegate {
    private var webView: WKWebView!
    private var server: LocalAssetServer?
    private var held = Set<String>()
    private var keys: [GameKeyButton] = []
    private let loading = UILabel()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black
        let configuration = WKWebViewConfiguration()
        configuration.websiteDataStore = .default()
        configuration.allowsInlineMediaPlayback = true
        configuration.mediaTypesRequiringUserActionForPlayback = []
        configuration.userContentController.addUserScript(WKUserScript(source: Self.layoutScript,
            injectionTime: .atDocumentEnd, forMainFrameOnly: true))
        webView = WKWebView(frame: .zero, configuration: configuration)
        webView.isOpaque = false
        webView.backgroundColor = .black
        webView.scrollView.backgroundColor = .black
        webView.scrollView.isScrollEnabled = false
        webView.navigationDelegate = self
        view.addSubview(webView)
        for (title, code) in [("◀", "ArrowLeft"), ("▶", "ArrowRight"),
            ("▲", "ArrowUp"), ("▼", "ArrowDown"), ("跳跃", "AltLeft"),
            ("攻击", "ControlLeft"), ("拾取", "KeyZ"), ("背包", "KeyI"),
            ("技能", "KeyK"), ("菜单", "Escape"), ("确认", "Enter")] {
            let button = GameKeyButton(title, code: code)
            button.addTarget(self, action: #selector(keyDown(_:)), for: .touchDown)
            button.addTarget(self, action: #selector(keyUp(_:)),
                for: [.touchUpInside, .touchUpOutside, .touchCancel, .touchDragExit])
            keys.append(button)
            view.addSubview(button)
        }
        loading.text = "正在加载原版地图和角色…"
        loading.textColor = .white
        loading.textAlignment = .center
        loading.font = .systemFont(ofSize: 17)
        view.addSubview(loading)
        NotificationCenter.default.addObserver(self, selector: #selector(suspend),
            name: UIApplication.willResignActiveNotification, object: nil)
        guard let root = Bundle.main.url(forResource: "WebContent", withExtension: nil) else {
            loading.text = "安装包缺少游戏资源，无法进入游戏。"; return
        }
        let server = LocalAssetServer(root: root)
        self.server = server
        do {
            try server.start { [weak self] result in
                switch result {
                case .success(let url): self?.webView.load(URLRequest(url: url))
                case .failure: self?.loading.text = "本机资源服务启动失败，请重新打开 App。"
                }
            }
        } catch { loading.text = "本机资源服务创建失败，请重新打开 App。" }
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        webView.frame = view.bounds
        loading.frame = CGRect(x: 10, y: view.bounds.midY - 25, width: view.bounds.width - 20, height: 50)
        let margin = max(12, max(view.safeAreaInsets.left, view.safeAreaInsets.right))
        let bottom = view.bounds.height - max(14, view.safeAreaInsets.bottom) - 56
        let right = view.bounds.width - margin
        let frames = [CGRect(x: margin, y: bottom, width: 54, height: 54),
            CGRect(x: margin + 64, y: bottom, width: 54, height: 54),
            CGRect(x: margin + 32, y: bottom - 66, width: 54, height: 54),
            CGRect(x: margin + 32, y: bottom - 132, width: 54, height: 48),
            CGRect(x: right - 66, y: bottom, width: 66, height: 56),
            CGRect(x: right - 142, y: bottom - 42, width: 68, height: 68),
            CGRect(x: right - 66, y: bottom - 76, width: 66, height: 48),
            CGRect(x: right - 138, y: 18, width: 62, height: 36),
            CGRect(x: right - 66, y: 18, width: 62, height: 36),
            CGRect(x: margin, y: 18, width: 62, height: 36),
            CGRect(x: right - 66, y: bottom - 142, width: 66, height: 48)]
        for (index, button) in keys.enumerated() { button.frame = frames[index] }
    }

    @objc private func keyDown(_ button: GameKeyButton) {
        guard !held.contains(button.code) else { return }
        held.insert(button.code)
        button.alpha = 1
        dispatchKey(button.code, down: true)
    }
    @objc private func keyUp(_ button: GameKeyButton) {
        held.remove(button.code)
        button.alpha = 0.85
        dispatchKey(button.code, down: false)
    }
    private func dispatchKey(_ code: String, down: Bool) {
        guard let payload = try? JSONSerialization.data(withJSONObject: [code, down]),
              let json = String(data: payload, encoding: .utf8) else { return }
        let script = """
        (() => {
          const [code, down] = \(json);
          const canvas = document.querySelector('#viewport canvas');
          if (!canvas) return;
          canvas.focus({preventScroll:true});
          const names = {AltLeft:'Alt',ControlLeft:'Control',KeyZ:'z',KeyI:'i',KeyK:'k'};
          const event = new KeyboardEvent(down?'keydown':'keyup',
            {key:names[code]||code,code,bubbles:true,cancelable:true});
          canvas.dispatchEvent(event);
        })();
        """
        webView.evaluateJavaScript(script, completionHandler: nil)
    }
    @objc private func suspend() {
        for code in held { dispatchKey(code, down: false) }
        held.removeAll()
        webView.evaluateJavaScript("window.dispatchEvent(new Event('blur'))", completionHandler: nil)
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) { loading.isHidden = true }
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        loading.isHidden = false; loading.text = "游戏页面加载失败，请重新打开 App。"
    }
    func webView(_ webView: WKWebView, decidePolicyFor action: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = action.request.url else { decisionHandler(.cancel); return }
        decisionHandler(url.host == "127.0.0.1" || url.absoluteString == "about:blank" ? .allow : .cancel)
    }
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask { .landscape }
    override var prefersStatusBarHidden: Bool { true }
    override var prefersHomeIndicatorAutoHidden: Bool { true }
    deinit { NotificationCenter.default.removeObserver(self) }

    // Preserve the desktop client's original pixel coordinates and artwork.
    private static let layoutScript = #"""
    (() => {
      const style = document.createElement('style');
      style.textContent = '.inspection-chrome{display:none!important}html{overflow:hidden;background:#000}body{position:absolute!important;left:0;top:0;width:1024px!important;height:768px!important;margin:0!important;transform-origin:0 0!important}main{width:1024px;height:768px}';
      document.head.appendChild(style);
      const meta = document.querySelector('meta[name="viewport"]');
      if (meta) meta.content = 'width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no';
      function fit() {
        const scale = Math.min(innerWidth/1024,innerHeight/768);
        const x = (innerWidth-1024*scale)/2;
        const y = (innerHeight-768*scale)/2;
        document.body.style.transform = `translate(${x}px,${y}px) scale(${scale})`;
      }
      window.addEventListener('resize',fit);
      fit();
    })();
    """#
}
