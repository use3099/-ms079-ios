import SpriteKit

extension UIColor {
    convenience init(hex: UInt32, alpha: CGFloat = 1) {
        self.init(red: CGFloat((hex >> 16) & 255) / 255,
                  green: CGFloat((hex >> 8) & 255) / 255,
                  blue: CGFloat(hex & 255) / 255, alpha: alpha)
    }
}

enum Art {
    @discardableResult static func box(_ parent: SKNode, _ x: CGFloat, _ y: CGFloat,
        _ w: CGFloat, _ h: CGFloat, _ color: UInt32, radius: CGFloat = 0) -> SKShapeNode {
        let n = SKShapeNode(rectOf: CGSize(width: w, height: h), cornerRadius: radius)
        n.position = CGPoint(x: x, y: y)
        n.fillColor = UIColor(hex: color)
        n.strokeColor = .clear
        parent.addChild(n)
        return n
    }

    @discardableResult static func oval(_ parent: SKNode, _ x: CGFloat, _ y: CGFloat,
        _ w: CGFloat, _ h: CGFloat, _ color: UInt32) -> SKShapeNode {
        let n = SKShapeNode(ellipseOf: CGSize(width: w, height: h))
        n.position = CGPoint(x: x, y: y)
        n.fillColor = UIColor(hex: color)
        n.strokeColor = .clear
        parent.addChild(n)
        return n
    }

    @discardableResult static func text(_ parent: SKNode, _ value: String, _ x: CGFloat,
        _ y: CGFloat, _ size: CGFloat = 16, _ color: UInt32 = 0xF5F1D9) -> SKLabelNode {
        let n = SKLabelNode(fontNamed: "PingFangSC-Semibold")
        n.text = value
        n.fontSize = size
        n.fontColor = UIColor(hex: color)
        n.position = CGPoint(x: x, y: y)
        n.verticalAlignmentMode = .center
        parent.addChild(n)
        return n
    }

    static func polygon(_ parent: SKNode, points: [CGPoint], color: UInt32) {
        let p = CGMutablePath()
        guard let first = points.first else { return }
        p.move(to: first)
        for point in points.dropFirst() { p.addLine(to: point) }
        p.closeSubpath()
        let n = SKShapeNode(path: p)
        n.fillColor = UIColor(hex: color)
        n.strokeColor = .clear
        parent.addChild(n)
    }

    static func hero() -> SKNode {
        let n = SKNode()
        oval(n, 0, 1, 43, 9, 0x365349).alpha = 0.35
        let left = box(n, -9, 11, 13, 23, 0x263B50, radius: 3); left.name = "legL"
        let right = box(n, 9, 11, 13, 23, 0x263B50, radius: 3); right.name = "legR"
        box(n, -10, 3, 17, 8, 0x54392F, radius: 2)
        box(n, 10, 3, 17, 8, 0x54392F, radius: 2)
        box(n, -3, 34, 31, 29, 0x517C92, radius: 5)
        box(n, -3, 23, 32, 5, 0xAC8052)
        box(n, -19, 35, 10, 19, 0xF4CFA6, radius: 4)
        box(n, 16, 34, 10, 19, 0xF4CFA6, radius: 4)
        let scarf = box(n, -18, 45, 28, 8, 0xE9AD52, radius: 3); scarf.zRotation = -0.2
        oval(n, 0, 61, 40, 41, 0xF3CEAA)
        oval(n, -2, 74, 43, 25, 0x5B4038)
        box(n, -16, 64, 9, 19, 0x5B4038, radius: 3)
        box(n, 4, 71, 24, 11, 0x5B4038, radius: 3).zRotation = -0.3
        box(n, -3, 59, 3, 7, 0x293B42, radius: 1)
        box(n, 12, 59, 3, 7, 0x293B42, radius: 1)
        oval(n, 7, 51, 5, 2, 0xAE7768)
        box(n, 23, 40, 5, 36, 0xD9E9E7, radius: 2).zRotation = -0.25
        box(n, 20, 26, 16, 4, 0xDDB25B, radius: 1)
        box(n, 19, 20, 5, 9, 0x6D4A3D, radius: 1)
        return n
    }

    static func slime(_ kind: Int) -> SKNode {
        let n = SKNode()
        let color: UInt32 = kind == 0 ? 0x89C49B : 0xD5A0BC
        oval(n, 0, 2, 52, 9, 0x345443).alpha = 0.3
        oval(n, 0, 20, 50, 37, color)
        oval(n, -9, 29, 16, 9, 0xE0EEC9).alpha = 0.65
        oval(n, -10, 18, 4, 7, 0x344E4B)
        oval(n, 10, 18, 4, 7, 0x344E4B)
        oval(n, 0, 11, 6, 3, 0x527B63)
        return n
    }

    static func tree(_ parent: SKNode, x: CGFloat, y: CGFloat, scale: CGFloat = 1) {
        let n = SKNode(); n.position = CGPoint(x: x, y: y); n.setScale(scale); parent.addChild(n)
        box(n, 0, 65, 24, 130, 0x80624C, radius: 7)
        box(n, 4, 65, 6, 117, 0x997952, radius: 2)
        oval(n, -32, 131, 118, 100, 0x608D77)
        oval(n, 35, 142, 128, 111, 0x79A382)
        oval(n, 0, 180, 135, 115, 0x8FB38A)
        oval(n, -25, 196, 76, 55, 0xAEC799)
    }

    static func cottage(_ parent: SKNode, x: CGFloat) {
        let n = SKNode(); n.position = CGPoint(x: x, y: 126); parent.addChild(n)
        box(n, 0, 61, 150, 122, 0xEEE2BD, radius: 8)
        box(n, 0, 7, 160, 14, 0xA28664, radius: 4)
        polygon(n, points: [CGPoint(x: -93, y: 114), CGPoint(x: 0, y: 182),
                           CGPoint(x: 93, y: 114)], color: 0xA87167)
        box(n, 0, 111, 179, 9, 0x7F5850, radius: 3)
        box(n, 4, 35, 34, 68, 0x786C56, radius: 14)
        oval(n, 14, 34, 4, 4, 0xE8C472)
        for xx: CGFloat in [-47, 48] {
            box(n, xx, 70, 30, 34, 0x7A918B, radius: 6)
            box(n, xx, 70, 3, 34, 0xF5DFAE)
            box(n, xx, 70, 30, 3, 0xF5DFAE)
        }
    }
}
