import Foundation

struct SaveData: Codable, Equatable {
    var version = 1
    var level = 1
    var xp = 0
    var gold = 0
    var kills = 0
    var potions = 5
    var questClaimed = false
    var hp = 100
    var x: Double = 180

    var maxHP: Int { 100 + (level - 1) * 20 }
    var nextLevelXP: Int { 40 + (level - 1) * 25 }
    var attack: Int { 18 + (level - 1) * 4 }

    mutating func gainXP(_ amount: Int) {
        xp += max(0, amount)
        while xp >= nextLevelXP && level < 100 {
            xp -= nextLevelXP
            level += 1
            hp = maxHP
        }
    }

    @discardableResult mutating func drinkPotion() -> Bool {
        guard potions > 0, hp < maxHP else { return false }
        potions -= 1
        hp = min(maxHP, hp + 65)
        return true
    }

    @discardableResult mutating func claimQuest() -> Bool {
        guard kills >= 8, !questClaimed else { return false }
        questClaimed = true
        gold += 100
        potions += 3
        gainXP(60)
        return true
    }

    mutating func sanitize() {
        level = min(100, max(1, level))
        xp = min(max(0, xp), nextLevelXP - 1)
        gold = min(999_999_999, max(0, gold))
        kills = min(999_999, max(0, kills))
        potions = min(999, max(0, potions))
        hp = min(maxHP, max(1, hp))
        x = x.isFinite ? min(3040, max(40, x)) : 180
    }
}

struct SaveStore {
    let url: URL

    static let shared = SaveStore(url: FileManager.default.urls(for: .documentDirectory,
        in: .userDomainMask)[0].appendingPathComponent("offline-save-v1.json"))

    func load() -> SaveData {
        guard let data = try? Data(contentsOf: url),
              var save = try? JSONDecoder().decode(SaveData.self, from: data), save.version == 1
        else { return SaveData() }
        save.sanitize()
        return save
    }

    func write(_ save: SaveData) throws {
        try JSONEncoder().encode(save).write(to: url, options: .atomic)
    }
}

struct Ledge {
    let left: Double
    let right: Double
    let y: Double
}

struct PlayerMotion {
    var x: Double = 180
    var y: Double = 126
    var vy: Double = 0
    var grounded = false

    mutating func step(dt: Double, direction: Double, ledges: [Ledge]) {
        let dt = min(1.0 / 30, max(0, dt))
        x = min(3040, max(40, x + direction * 225 * dt))
        let previousY = y
        vy -= 1450 * dt
        y += vy * dt
        grounded = false
        if vy <= 0 {
            let landings = ledges.filter {
                x + 12 > $0.left && x - 12 < $0.right && previousY >= $0.y && y <= $0.y
            }
            if let landing = landings.max(by: { $0.y < $1.y }) {
                y = landing.y
                vy = 0
                grounded = true
            }
        }
    }

    mutating func jump() { if grounded { vy = 590; grounded = false } }
}
