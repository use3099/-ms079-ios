import SpriteKit

private final class Mob {
    let node: SKNode
    let home: Double
    let floor: Double
    let kind: Int
    var hp = 45
    var direction: Double = 1
    var respawnAt: TimeInterval = 0
    init(x: Double, floor: Double, kind: Int) {
        home = x; self.floor = floor; self.kind = kind
        node = Art.slime(kind)
        node.position = CGPoint(x: x, y: floor)
        hp = kind == 0 ? 45 : 70
    }
}

final class GameScene: SKScene {
    var safeMargin: CGFloat = 28
    private let world = SKNode()
    private let distant = SKNode()
    private let gameCamera = SKCameraNode()
    private let hud = SKNode()
    private let controls = SKNode()
    private let overlay = SKNode()
    private let hero = Art.hero()
    private var save = SaveStore.shared.load()
    private var motion = PlayerMotion()
    private var mobs: [Mob] = []
    private let ledges = [Ledge(left: 0, right: 3100, y: 126),
                          Ledge(left: 730, right: 1010, y: 245),
                          Ledge(left: 1180, right: 1430, y: 340),
                          Ledge(left: 1630, right: 1930, y: 245),
                          Ledge(left: 2250, right: 2560, y: 280)]
    private var touchesByID: [ObjectIdentifier: String] = [:]
    private var buttons: [String: SKShapeNode] = [:]
    private var hpBar = SKSpriteNode(color: UIColor(hex: 0xD98277), size: CGSize(width: 170, height: 8))
    private var xpBar = SKSpriteNode(color: UIColor(hex: 0xD9B867), size: CGSize(width: 170, height: 4))
    private var stats = SKLabelNode()
    private var healthText = SKLabelNode()
    private var questText = SKLabelNode()
    private var areaText = SKLabelNode()
    private var potionText = SKLabelNode()
    private var toastLabel = SKLabelNode()
    private var lastTime: TimeInterval = 0
    private var clock: TimeInterval = 0
    private var lastSave: TimeInterval = 0
    private var attackUntil: TimeInterval = 0
    private var nextAttack: TimeInterval = 0
    private var invulnerableUntil: TimeInterval = 0
    private var facing: CGFloat = 1
    private var playing = false
    private var built = false

    override func didMove(to view: SKView) {
        guard !built else { return }
        built = true
        backgroundColor = UIColor(hex: 0xC6DFDA)
        addChild(distant); addChild(world)
        addChild(gameCamera); camera = gameCamera
        gameCamera.addChild(hud); hud.zPosition = 100
        gameCamera.addChild(overlay); overlay.zPosition = 200
        createLandscape()
        world.addChild(hero); hero.zPosition = 10
        motion.x = save.x
        for (index, x) in [820.0, 1060, 1350, 1620, 1840, 2050, 2380, 2740, 2920].enumerated() {
            let mob = Mob(x: x, floor: 126, kind: index % 3 == 2 ? 1 : 0)
            mobs.append(mob); world.addChild(mob.node); mob.node.zPosition = 8
        }
        createHUD()
        layoutHUD()
        updateCamera()
        showMenu(initial: true)
    }

    override func didChangeSize(_ oldSize: CGSize) { if built { layoutHUD() } }

    private func createLandscape() {
        // Original procedural placeholder art; no official WZ assets are bundled.
        Art.oval(distant, 790, 425, 100, 100, 0xF5E9BF).alpha = 0.85
        for i in 0..<12 {
            let x = CGFloat(i) * 280 - 250
            Art.oval(distant, x, 96, 640, 360 + CGFloat(i % 3) * 50, 0xA5C6BA)
            Art.oval(distant, x + 120, 28, 490, 290, 0x8FB3A5)
        }
        for i in 0..<10 {
            let cloud = SKNode(); cloud.position = CGPoint(x: CGFloat(i) * 350, y: 420 + CGFloat(i % 3) * 28)
            Art.oval(cloud, 0, 0, 110, 22, 0xEDF2DA)
            Art.oval(cloud, -20, 10, 52, 28, 0xEDF2DA)
            distant.addChild(cloud)
        }
        for i in 0..<18 { Art.tree(world, x: CGFloat(i) * 200 + 40, y: 126, scale: CGFloat(0.65 + Double(i % 3) * 0.14)) }
        Art.box(world, 1550, 25, 3100, 202, 0xA39170)
        Art.box(world, 1550, 106, 3100, 34, 0x6B926A, radius: 6)
        Art.box(world, 1550, 122, 3100, 9, 0xB4C88B, radius: 3)
        for i in 0..<90 {
            let x = CGFloat(i) * 37
            Art.oval(world, x, 42 + CGFloat(i % 4) * 13, 10, 6, 0xBEAC83)
            if i % 3 == 0 {
                Art.box(world, x, 133, 2, 14, 0x6F985A)
                Art.oval(world, x, 141, 8, 6, i % 2 == 0 ? 0xEDCD8F : 0xDEA3A0)
            }
        }
        for ledge in ledges.dropFirst() {
            let x = CGFloat((ledge.left + ledge.right) / 2)
            let w = CGFloat(ledge.right - ledge.left)
            Art.box(world, x, CGFloat(ledge.y) - 16, w, 32, 0x99856B, radius: 8)
            Art.box(world, x, CGFloat(ledge.y) - 2, w + 6, 10, 0xB0C584, radius: 5)
        }
        Art.cottage(world, x: 280)
        let npc = Art.hero(); npc.position = CGPoint(x: 480, y: 126); npc.setScale(0.9)
        world.addChild(npc)
        Art.text(world, "守林人", 480, 220, 14, 0x496859)
        Art.box(world, 610, 152, 8, 54, 0x94765A)
        Art.box(world, 610, 175, 94, 30, 0xD7C6A2, radius: 4)
        Art.text(world, "微风林地 →", 610, 175, 12, 0x5D674E)
        Art.text(world, "林间小屋", 280, 330, 19, 0x496859)
        Art.text(world, "向右探索 · 击败 8 只团子怪后回守林人领奖", 1540, 470, 17, 0x4E7469)
    }

    private func createHUD() {
        hud.addChild(controls)
        let panel = Art.box(hud, 0, 0, 256, 85, 0x213F41, radius: 16)
        panel.alpha = 0.9; panel.name = "statusPanel"
        stats = Art.text(hud, "", 0, 0, 17); stats.horizontalAlignmentMode = .left
        healthText = Art.text(hud, "", 0, 0, 11); healthText.horizontalAlignmentMode = .left
        hpBar.anchorPoint = CGPoint(x: 0, y: 0.5); hud.addChild(hpBar)
        xpBar.anchorPoint = CGPoint(x: 0, y: 0.5); hud.addChild(xpBar)
        areaText = Art.text(hud, "", 0, 0, 16, 0x355D53)
        questText = Art.text(hud, "", 0, 0, 13, 0x355D53)
        toastLabel = Art.text(hud, "", 0, 125, 17, 0xFFFFFF)
        toastLabel.zPosition = 10
        makeButton("left", title: "◀", width: 76, height: 70)
        makeButton("right", title: "▶", width: 76, height: 70)
        makeButton("jump", title: "跳跃", width: 74, height: 70)
        makeButton("attack", title: "攻击", width: 86, height: 86, color: 0xAC7757)
        makeButton("potion", title: "", width: 74, height: 48)
        potionText = Art.text(buttons["potion"]!, "", 0, 0, 14)
        makeButton("interact", title: "对话", width: 74, height: 48)
        makeButton("menu", title: "暂停", width: 66, height: 36)
        refreshHUD()
    }

    private func makeButton(_ key: String, title: String, width: CGFloat,
                            height: CGFloat, color: UInt32 = 0x315C59) {
        let button = Art.box(controls, 0, 0, width, height, color, radius: 20)
        button.name = key; button.alpha = 0.82
        button.strokeColor = UIColor(hex: 0xEEE5C8, alpha: 0.4); button.lineWidth = 1.5
        Art.text(button, title, 0, 0, 18)
        buttons[key] = button
    }

    func layoutHUD() {
        guard built else { return }
        let left = -size.width / 2 + safeMargin
        let right = size.width / 2 - safeMargin
        hud.childNode(withName: "statusPanel")?.position = CGPoint(x: left + 128, y: 209)
        stats.position = CGPoint(x: left + 16, y: 232)
        healthText.position = CGPoint(x: left + 16, y: 211)
        hpBar.position = CGPoint(x: left + 16, y: 194)
        xpBar.position = CGPoint(x: left + 16, y: 181)
        areaText.position = CGPoint(x: 0, y: 239)
        questText.position = CGPoint(x: 0, y: 215)
        buttons["menu"]?.position = CGPoint(x: right - 33, y: 237)
        buttons["left"]?.position = CGPoint(x: left + 42, y: -195)
        buttons["right"]?.position = CGPoint(x: left + 128, y: -195)
        buttons["jump"]?.position = CGPoint(x: right - 44, y: -192)
        buttons["attack"]?.position = CGPoint(x: right - 142, y: -182)
        buttons["potion"]?.position = CGPoint(x: right - 45, y: -99)
        buttons["interact"]?.position = CGPoint(x: left + 43, y: -105)
        if !playing { showMenu(initial: false) }
    }

    private func refreshHUD() {
        stats.text = "旅行者  Lv.\(save.level)   ·   \(save.gold) 金币"
        healthText.text = "生命 \(save.hp) / \(save.maxHP)     经验 \(save.xp) / \(save.nextLevelXP)"
        hpBar.xScale = CGFloat(save.hp) / CGFloat(save.maxHP)
        xpBar.xScale = CGFloat(save.xp) / CGFloat(save.nextLevelXP)
        questText.text = save.questClaimed ? "守林委托已完成 · 自由探索" : "守林委托  \(min(8, save.kills)) / 8"
        potionText.text = "药水 ×\(save.potions)"
        areaText.text = motion.x < 650 ? "林间小屋" : "微风林地"
        buttons["interact"]?.isHidden = abs(motion.x - 480) > 130
    }

    private func showMenu(initial: Bool) {
        playing = false
        clearControls()
        overlay.removeAllChildren()
        let shade = Art.box(overlay, 0, 0, size.width + 100, size.height + 100, 0x152E32)
        shade.alpha = 0.62
        Art.box(overlay, 0, 10, 470, 350, 0xF1E9D0, radius: 24)
        Art.text(overlay, "枫叶单机", 0, 130, 37, 0x31584D)
        Art.text(overlay, "微风林地 · iOS 单机试玩", 0, 85, 16, 0x748572)
        menuButton("resume", title: initial ? "开始 / 继续冒险" : "继续冒险", y: 26)
        menuButton("save", title: "保存进度", y: -34)
        Art.text(overlay, "左手移动 · 右手跳跃 / 攻击 · 药水回血", 0, -91, 13, 0x687D6B)
        Art.text(overlay, "进度保存在本机，卸载会删除存档", 0, -116, 12, 0x89927C)
        Art.text(overlay, "0.1 试玩版 · 临时美术 · 尚未接入 v079 服务器", 0, -143, 11, 0x89927C)
    }

    private func menuButton(_ key: String, title: String, y: CGFloat) {
        let n = Art.box(overlay, 0, y, 306, 46, 0x436D5E, radius: 13)
        n.name = key
        Art.text(n, title, 0, 0, 18)
    }

    func suspendAndSave() {
        guard built else { return }
        persist(silent: true)
        showMenu(initial: false)
        lastTime = 0
    }

    private func persist(silent: Bool = false) {
        save.x = motion.x
        do {
            try SaveStore.shared.write(save)
            if !silent { toast("进度已保存") }
        } catch { toast("保存失败，请检查设备可用空间") }
    }

    private func toast(_ message: String) {
        toastLabel.removeAllActions(); toastLabel.text = message; toastLabel.alpha = 1
        toastLabel.run(.sequence([.wait(forDuration: 2.4), .fadeOut(withDuration: 0.5)]))
    }

    private func action(at point: CGPoint, in parent: SKNode) -> String? {
        for node in parent.nodes(at: point) {
            var candidate: SKNode? = node
            while let current = candidate, current !== parent {
                if let name = current.name { return name }
                candidate = current.parent
            }
        }
        return nil
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
            if !playing {
                switch action(at: touch.location(in: overlay), in: overlay) {
                case "resume": playing = true; overlay.removeAllChildren(); lastTime = 0
                case "save": persist()
                default: break
                }
                continue
            }
            guard let key = action(at: touch.location(in: controls), in: controls) else { continue }
            touchesByID[ObjectIdentifier(touch)] = key
            switch key {
            case "jump": motion.jump()
            case "attack": attack()
            case "potion":
                if save.drinkPotion() { toast("生命恢复 +65"); refreshHUD(); persist(silent: true) }
                else { toast(save.potions == 0 ? "药水不足，回小屋找守林人" : "生命已满") }
            case "interact": interact()
            case "menu": persist(silent: true); showMenu(initial: false)
            default: break
            }
        }
        highlightControls()
    }

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard playing else { return }
        for touch in touches {
            let id = ObjectIdentifier(touch)
            if touchesByID[id] == "left" || touchesByID[id] == "right" {
                let key = action(at: touch.location(in: controls), in: controls)
                touchesByID[id] = (key == "left" || key == "right") ? key : "move-off"
            } else if touchesByID[id] == "move-off" {
                let key = action(at: touch.location(in: controls), in: controls)
                if key == "left" || key == "right" { touchesByID[id] = key }
            }
        }
        highlightControls()
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches { touchesByID.removeValue(forKey: ObjectIdentifier(touch)) }
        highlightControls()
    }
    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) { touchesEnded(touches, with: event) }

    private func highlightControls() {
        for (key, button) in buttons { button.alpha = touchesByID.values.contains(key) ? 1 : 0.82 }
    }
    private func clearControls() { touchesByID.removeAll(); highlightControls() }

    private func interact() {
        guard abs(motion.x - 480) < 130 else { return }
        save.hp = save.maxHP
        if save.claimQuest() { toast("委托完成！+100 金币、3 瓶药水、60 经验") }
        else if save.potions < 3 { save.potions = 3; toast("守林人：补给给你，路上小心！") }
        else { toast(save.questClaimed ? "守林人：欢迎回来，生命已恢复。" : "守林人：击败 8 只团子怪，我会给你奖励。") }
        refreshHUD(); persist(silent: true)
    }

    private func attack() {
        guard clock >= nextAttack else { return }
        nextAttack = clock + 0.4; attackUntil = clock + 0.18
        let slash = SKShapeNode()
        let path = CGMutablePath()
        path.addArc(center: .zero, radius: 65, startAngle: -.pi / 3,
                    endAngle: .pi / 3, clockwise: false)
        slash.path = path; slash.strokeColor = UIColor(hex: 0xFFF1C5)
        slash.lineWidth = 10; slash.glowWidth = 3
        slash.position = CGPoint(x: motion.x, y: motion.y + 33)
        slash.xScale = facing; slash.zPosition = 20; world.addChild(slash)
        slash.run(.sequence([.fadeOut(withDuration: 0.18), .removeFromParent()]))
        for mob in mobs where mob.hp > 0 {
            let dx = (Double(mob.node.position.x) - motion.x) * Double(facing)
            let dy = abs(Double(mob.node.position.y) - motion.y)
            if dx > -18 && dx < 104 && dy < 65 {
                let damage = save.attack + Int.random(in: 0...5)
                mob.hp -= damage
                floatingText("\(damage)", at: mob.node.position, color: 0xFFF0B1)
                mob.node.position.x = min(3035, max(660, mob.node.position.x + facing * 22))
                mob.node.alpha = 0.35
                mob.node.run(.fadeAlpha(to: 1, duration: 0.14))
                if mob.hp <= 0 {
                    mob.respawnAt = clock + 7
                    mob.node.removeAllActions()
                    mob.node.run(.sequence([.group([.moveBy(x: facing * 22, y: 20, duration: 0.2),
                        .fadeOut(withDuration: 0.22)]), .hide()]))
                    save.kills += 1; save.gold += mob.kind == 0 ? 8 : 12
                    let level = save.level
                    save.gainXP(mob.kind == 0 ? 16 : 24)
                    if save.kills % 4 == 0 { save.potions += 1 }
                    if save.level > level { toast("升级！Lv.\(save.level) · 生命已恢复") }
                    if save.kills == 8 { toast("委托完成，回小屋找守林人领奖！") }
                    refreshHUD(); persist(silent: true)
                }
            }
        }
    }

    private func floatingText(_ text: String, at p: CGPoint, color: UInt32) {
        let n = Art.text(world, text, p.x, p.y + 65, 24, color); n.zPosition = 30
        n.run(.sequence([.group([.moveBy(x: 0, y: 43, duration: 0.7),
                                  .fadeOut(withDuration: 0.7)]), .removeFromParent()]))
    }

    override func update(_ currentTime: TimeInterval) {
        guard playing else { lastTime = currentTime; return }
        let dt = lastTime == 0 ? 1.0 / 60 : min(1.0 / 30, max(0, currentTime - lastTime))
        lastTime = currentTime; clock += dt
        let values = touchesByID.values
        let direction: Double = (values.contains("right") ? 1 : 0) - (values.contains("left") ? 1 : 0)
        if direction != 0 { facing = direction > 0 ? 1 : -1 }
        motion.step(dt: dt, direction: direction, ledges: ledges)
        if values.contains("attack") { attack() }
        hero.position = CGPoint(x: motion.x, y: motion.y)
        hero.xScale = facing
        let phase = CGFloat(clock * 12)
        let stride: CGFloat = direction == 0 || !motion.grounded ? 0 : sin(phase) * 0.4
        hero.childNode(withName: "legL")?.zRotation = stride
        hero.childNode(withName: "legR")?.zRotation = -stride
        hero.yScale = clock < attackUntil ? 1.03 : 1 + sin(CGFloat(clock * 3)) * 0.012
        hero.alpha = clock < invulnerableUntil ? (sin(clock * 32) > 0 ? 0.4 : 1) : 1
        for mob in mobs {
            if mob.hp <= 0 {
                if clock >= mob.respawnAt {
                    mob.hp = mob.kind == 0 ? 45 : 70
                    mob.node.removeAllActions(); mob.node.isHidden = false; mob.node.alpha = 1
                    mob.node.position = CGPoint(x: mob.home, y: mob.floor)
                }
                continue
            }
            if abs(Double(mob.node.position.x) - mob.home) > 100 { mob.direction *= -1 }
            mob.node.position.x += mob.direction * (mob.kind == 0 ? 38 : 48) * dt
            mob.node.yScale = 1 + sin(CGFloat(clock * 5 + mob.home)) * 0.08
            if abs(Double(mob.node.position.x) - motion.x) < 34 && abs(mob.floor - motion.y) < 34 && clock >= invulnerableUntil {
                save.hp = max(0, save.hp - (mob.kind == 0 ? 12 : 18))
                invulnerableUntil = clock + 1.2
                floatingText("−\(mob.kind == 0 ? 12 : 18)", at: hero.position, color: 0xC45454)
                if save.hp == 0 {
                    save.hp = save.maxHP; motion = PlayerMotion(); motion.x = 420
                    toast("已回到小屋 · 进度保留，生命恢复")
                    persist(silent: true)
                }
            }
        }
        updateCamera(); refreshHUD()
        if clock - lastSave > 10 { persist(silent: true); lastSave = clock }
    }

    private func updateCamera() {
        let half = Double(size.width / 2)
        gameCamera.position = CGPoint(x: min(max(half, motion.x), max(half, 3100 - half)), y: 270)
        distant.position.x = gameCamera.position.x * 0.65 - 100
    }
}
