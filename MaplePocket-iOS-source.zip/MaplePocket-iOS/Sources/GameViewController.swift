import SpriteKit
import UIKit

final class GameViewController: UIViewController {
    private let game = GameScene(size: CGSize(width: 1080, height: 540))

    override func loadView() { view = SKView() }

    override func viewDidLoad() {
        super.viewDidLoad()
        guard let skView = view as? SKView else { return }
        skView.isMultipleTouchEnabled = true
        skView.ignoresSiblingOrder = true
        skView.preferredFramesPerSecond = 60
        game.scaleMode = .resizeFill
        skView.presentScene(game)
        NotificationCenter.default.addObserver(self, selector: #selector(suspendGame),
            name: UIApplication.willResignActiveNotification, object: nil)
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        // Keep a constant logical height across every iPhone/iPad aspect ratio.
        let height = max(view.bounds.height, 1)
        game.size = CGSize(width: view.bounds.width / height * 540, height: 540)
        game.safeMargin = max(24, max(view.safeAreaInsets.left / height * 540 + 12,
                                     view.safeAreaInsets.right / height * 540 + 12))
        game.layoutHUD()
    }

    @objc private func suspendGame() { game.suspendAndSave() }
    override var prefersStatusBarHidden: Bool { true }
    override var prefersHomeIndicatorAutoHidden: Bool { true }
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask { .landscape }
    override var shouldAutorotate: Bool { true }
    deinit { NotificationCenter.default.removeObserver(self) }
}
