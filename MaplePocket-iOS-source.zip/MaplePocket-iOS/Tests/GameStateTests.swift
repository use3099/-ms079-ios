import XCTest
@testable import MaplePocket

final class GameStateTests: XCTestCase {
    func testLevelUpConsumesXPAndHeals() {
        var s = SaveData()
        s.hp = 3
        s.gainXP(110)
        XCTAssertEqual(s.level, 3)
        XCTAssertEqual(s.xp, 5)
        XCTAssertEqual(s.hp, 140)
    }

    func testPotionCannotBeWastedAndQuestCannotBeClaimedTwice() {
        var s = SaveData()
        XCTAssertFalse(s.drinkPotion())
        XCTAssertEqual(s.potions, 5)
        s.hp = 10
        XCTAssertTrue(s.drinkPotion())
        XCTAssertEqual(s.hp, 75)
        XCTAssertFalse(s.claimQuest())
        s.kills = 8
        XCTAssertTrue(s.claimQuest())
        let claimed = s
        XCTAssertFalse(s.claimQuest())
        XCTAssertEqual(s, claimed)
    }

    func testSaveRoundtripAndCorruptFileFallback() throws {
        let url = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: url) }
        let store = SaveStore(url: url)
        var save = SaveData()
        save.gold = 88
        save.x = 2020
        try store.write(save)
        XCTAssertEqual(store.load(), save)
        try Data("broken".utf8).write(to: url)
        XCTAssertEqual(store.load(), SaveData())
    }

    func testPlatformLandingAndJumpThroughUnderside() {
        let ledges = [Ledge(left: 0, right: 3100, y: 126), Ledge(left: 100, right: 400, y: 240)]
        var p = PlayerMotion(x: 200, y: 245, vy: -200)
        p.step(dt: 1.0 / 30, direction: 0, ledges: ledges)
        XCTAssertEqual(p.y, 240)
        XCTAssertTrue(p.grounded)
        p = PlayerMotion(x: 200, y: 235, vy: 500)
        p.step(dt: 1.0 / 30, direction: 0, ledges: ledges)
        XCTAssertGreaterThan(p.y, 240)
        XCTAssertFalse(p.grounded)
    }
}
