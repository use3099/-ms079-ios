$ErrorActionPreference = 'Stop'
$repo = 'use3099/-ms079-ios'
$source = Split-Path $PSScriptRoot -Parent

try {
    foreach ($tool in @('git', 'gh')) {
        if (-not (Get-Command $tool -ErrorAction SilentlyContinue)) {
            Write-Host 'Install Git and GitHub CLI first, then open this launcher again.'
            Write-Host 'Official downloads: https://git-scm.com/download/win and https://cli.github.com/'
            throw "Missing required tool: $tool"
        }
    }
    Write-Host "Upload the offline iOS prototype to $repo and start GitHub Actions."
    Write-Host 'Sign in to GitHub in your browser. Never send your password to ChatGPT.'
    & gh auth login --hostname github.com --git-protocol https --web --scopes 'repo,workflow'
    if ($LASTEXITCODE -ne 0) { throw 'GitHub login did not complete.' }
    & gh auth setup-git
    if ($LASTEXITCODE -ne 0) { throw 'Unable to configure GitHub credentials.' }
    $checkout = Join-Path $env:TEMP ('ms079-ios-' + [guid]::NewGuid().ToString('N'))
    & git clone --branch main "https://github.com/$repo.git" $checkout
    if ($LASTEXITCODE -ne 0) { throw 'Repository clone failed.' }
    # Never overwrite existing application code with this initial scaffold.
    foreach ($existing in @('Sources', 'project.yml', '.github/workflows/ios.yml')) {
        if (Test-Path (Join-Path $checkout $existing)) {
            throw "Repository already contains $existing. Initial uploader stopped without changing it."
        }
    }
    foreach ($item in @('Sources', 'Tests', 'scripts', '.github', 'project.yml', '.gitignore', 'README.md', 'Upload-Windows.cmd')) {
        Copy-Item -LiteralPath (Join-Path $source $item) -Destination $checkout -Recurse -Force
    }
    Push-Location $checkout
    try {
        & git config user.name 'use3099'
        & git config user.email '152139095+use3099@users.noreply.github.com'
        & git add --all
        if ($LASTEXITCODE -ne 0) { throw 'Staging failed.' }
        & git commit -m 'Add native offline iOS prototype and unsigned IPA build workflow'
        if ($LASTEXITCODE -ne 0) { throw 'Commit failed.' }
        & git push origin HEAD:main
        if ($LASTEXITCODE -ne 0) { throw 'Push failed. Check repository and workflow write permissions.' }
    } finally { Pop-Location }
    Write-Host 'Uploaded successfully. The macOS build will run in GitHub Actions.' -ForegroundColor Green
    Write-Host "Actions: https://github.com/$repo/actions"
    Write-Host "IPA releases after a successful build: https://github.com/$repo/releases"
    Start-Process "https://github.com/$repo/actions"
} catch {
    Write-Host $_.Exception.Message -ForegroundColor Red
    exit 1
}
