#!/usr/bin/env bash
set -euo pipefail
APP='build/Build/Products/Release-iphoneos/MaplePocket.app'
test -d "$APP"
test -s "$APP/MaplePocket"
lipo -verify_arch arm64 "$APP/MaplePocket"
mkdir -p dist/Payload
cp -R "$APP" dist/Payload/
rm -rf dist/Payload/MaplePocket.app/_CodeSignature
rm -f dist/Payload/MaplePocket.app/embedded.mobileprovision
(cd dist && ditto -c -k --keepParent Payload MaplePocket-unsigned.ipa)
python3 - <<'PY'
import hashlib, plistlib, zipfile
from pathlib import Path
p = Path('dist/MaplePocket-unsigned.ipa')
with zipfile.ZipFile(p) as z:
    assert z.testzip() is None, 'IPA ZIP integrity failure'
    info = plistlib.loads(z.read('Payload/MaplePocket.app/Info.plist'))
    assert info['CFBundleIdentifier'] == 'com.use3099.ms079ios'
    assert info['CFBundleExecutable'] == 'MaplePocket'
    binary = z.read('Payload/MaplePocket.app/MaplePocket')
    assert len(binary) > 4096, 'Missing application executable'
    assert 'iPhoneOS' in info['CFBundleSupportedPlatforms'], 'Simulator binary cannot be installed'
    assert info.get('UISupportedInterfaceOrientations'), 'Missing landscape configuration'
    print('Verified device application:', info['CFBundleIdentifier'], info['CFBundleShortVersionString'])
Path('dist/SHA256SUMS.txt').write_text(hashlib.sha256(p.read_bytes()).hexdigest() + '  ' + p.name + '\n')
PY
