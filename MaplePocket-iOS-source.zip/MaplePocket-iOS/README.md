# 枫叶单机 · iOS 试玩工程

原生 Swift / SpriteKit 横屏单机原型，最低 iOS 15，支持 iPhone / iPad。

**这是独立的玩法试玩客户端，不是完整冒险岛 v079 移植版，也不是将 Java 服务端直接包装成 App。**
原需求参考 [mrzhqiang/ms079](https://github.com/mrzhqiang/ms079)。本版未复制该仓库代码、官方客户端或 WZ 资源；角色和地图由代码临时绘制。尚未实现 v079 网络协议和服务器连接，不能登录已有 v079 角色。

## 下载 IPA

提交代码到 `main` 后，GitHub Actions 的 **Build iPhone IPA** 会生成项目、运行 iPhone 模拟器单元测试、编译 arm64 真机 App、校验并打包 IPA。

- 成功后在本仓库 **Releases** 下载 `MaplePocket-unsigned.ipa`。
- 或打开 **Actions → Build iPhone IPA → 成功的运行 → Artifacts**，下载 `MaplePocket-unsigned-IPA`，解压取得 IPA。
- IPA **未签名**，需要用自己的证书 / 签名工具签名后安装。无需在仓库上传 Apple ID、密码或证书。
- 也可以在 Actions 页面点击 **Run workflow** 手动重打包。
- 如果云端构建尚未成功，不能把本项目源码当成已完成的 IPA。

## 玩法

左下左右移动，右下跳跃和攻击（攻击可长按，支持边走边跳边打）。药水恢复生命。击败 8 只团子怪后，回小屋附近找守林人，点击“对话”领奖。每四次击败怪物补充一瓶药水，怪物会刷新。升级自动恢复生命。生命耗尽回小屋，保留经验和金币。

每 10 秒、击败怪物、领取奖励、暂停及进入后台时自动保存。暂停菜单可手动保存。存档在本机 App 文档目录，**卸载会删除存档**；使用相同 Bundle ID 更新并保留 App 数据时可继续。

## 当前范围

- 一张含村落、林地和多层平台的地图。
- 一个近战角色、两种团子怪、升级、金币、补给和一次性守林委托。
- 没有官方地图 / 角色素材，没有职业转职、背包装备、商城、社交、联网及完整原版内容。
- 下阶段需单独实现资源管线与 v079 协议适配，才能连接自建服务器；本仓库不包含服务器端。

## Mac 本地构建（Windows 用户不需要这一步）

```sh
brew install xcodegen
xcodegen generate
xcodebuild build -project MaplePocket.xcodeproj -scheme MaplePocket \
  -configuration Release -sdk iphoneos -destination 'generic/platform=iOS' \
  -derivedDataPath build CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY=''
bash scripts/package-ipa.sh
```

测试覆盖升级经验结算、药水消耗、任务重复领取、存档往返 / 损坏回退以及单向平台碰撞。触屏手感、显示和安装仍需真机测试；模拟器测试通过不等于已做真机验证。
